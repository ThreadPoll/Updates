package com.capgemini.assetmgmt.service;

import java.util.HashMap;

import com.capgemini.assetmgmt.dao.AssetAuthenticationDAO;
import com.capgemini.assetmgmt.dao.AssetAuthenticationDAOImpl;
import com.capgemini.assetmgmt.dto.User;
import com.capgemini.assetmgmt.dto.UserType;
import com.capgemini.assetmgmt.exception.AssetAuthenticationException;

public class AssetAuthenticationServiceImpl implements AssetAuthenticationService{
	
	private AssetAuthenticationDAO authenticationDAO;
	public AssetAuthenticationServiceImpl() {
		authenticationDAO = new AssetAuthenticationDAOImpl();
	}

	
	@Override
	public boolean isValidUser(HashMap<String, String> userDetails)
			throws AssetAuthenticationException {
		User user = new User();
		user.setUserId(userDetails.get("userId"));
		user.setUserName(userDetails.get("userName"));
		user.setUserPassword(userDetails.get("userPassword"));
		user.setUserType(UserType.valueOf(userDetails.get("userType")));
		
		return authenticationDAO.isValidUser(user);
	}

}
