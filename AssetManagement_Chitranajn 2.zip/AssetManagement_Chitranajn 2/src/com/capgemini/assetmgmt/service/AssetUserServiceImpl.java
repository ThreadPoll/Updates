package com.capgemini.assetmgmt.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.capgemini.assetmgmt.dao.AssetUserDAO;
import com.capgemini.assetmgmt.dao.AssetUserDAOImpl;
import com.capgemini.assetmgmt.dto.Asset;
import com.capgemini.assetmgmt.dto.AssetAllocation;
import com.capgemini.assetmgmt.exception.AssetUserException;

public class AssetUserServiceImpl implements AssetUserService{
	
	private AssetUserDAO userDAO;
	public AssetUserServiceImpl() {
		userDAO = new AssetUserDAOImpl();
	}

	@Override
	public List<HashMap<String, String>> displayAsset()
			throws AssetUserException {
		List<HashMap<String, String>> assetList = new ArrayList<HashMap<String,String>>();
		
		List<Asset> myAssetList = userDAO.displayAsset();
		for (int index = 0; index < myAssetList.size(); index++) {
			Asset asset = myAssetList.get(index);
			
			HashMap<String, String> assetDetails = new HashMap<String, String>();
			assetDetails.put("assetId", asset.getAssetId()+"");
			assetDetails.put("assetName", asset.getAssetName());
			assetDetails.put("assetDes", asset.getAssetDes());
			assetDetails.put("quantity", asset.getQuantity()+"");
			assetDetails.put("status", asset.getStatus());
			
			assetList.add(assetDetails);
		}
		return assetList;
	}

	@Override
	public void raiseRequest(HashMap<String, String> allocationDetails)
			throws AssetUserException {
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		AssetAllocation assetAllocation = new AssetAllocation();
		assetAllocation.setAllocationId(Integer.parseInt(allocationDetails.get("allocationId")));
		assetAllocation.setAssetId(Integer.parseInt(allocationDetails.get("assetId")));
		assetAllocation.setEmpNo(Integer.parseInt(allocationDetails.get("empNo")));
		try {
			assetAllocation.setAllocationDate(formatter.parse((allocationDetails.get("allocationDate"))));
			assetAllocation.setReleaseDate(formatter.parse((allocationDetails.get("releaseDate"))));
		} catch (ParseException e) {
			throw new AssetUserException("Date Conversion Error");
		}
		userDAO.raiseRequest(assetAllocation);
	}
}
