package com.capgemini.assetmgmt.service;

import java.util.HashMap;
import java.util.List;

import com.capgemini.assetmgmt.exception.AssetAdminException;

public interface AssetAdminService {

	public void addAsset(HashMap<String , String> assetDetails) throws AssetAdminException;
	public void updateAsset(HashMap<String , String> assetDetails) throws AssetAdminException;
	public HashMap<String , String> searchAsset(String assetId) throws AssetAdminException;
	public List<HashMap<String , String>> displayRequest() throws AssetAdminException;
	public void actrequestAdmin(HashMap<String, String> actRequest) throws AssetAdminException;
}
