drop table user_master cascade constraints;
create table user_master(
userid varchar2(10),
username varchar2(20),
userpassword varchar2(20),
usertype varchar2(20)
);

insert into user_master values(1001,'Girjesh'	,'pass@123','admin');
insert into user_master values(1002,'Ashish'	,'pass@321','admin');
insert into user_master values(1003,'Dhairya'	,'pass@123','admin');
insert into user_master values(1004,'Vinod'		,'pass@321','admin');
insert into user_master values(1005,'Rajat'		,'pass@123','manager');
insert into user_master values(1006,'Kush'		,'pass@321','manager');
insert into user_master values(1007,'Sharib'	,'pass@123','manager');

drop table Department cascade constraints;
CREATE TABLE Department(
Dept_ID int PRIMARY KEY,
Dept_name varchar2(50)
);

insert into Department values(10,'Java');
insert into Department values(20,'Oracle');
insert into Department values(30,'MainFrame');
insert into Department values(40,'Business Intellegence');
insert into Department values(50,'Financial Services');

drop table Employee cascade constraints;
CREATE TABLE Employee(
Empno Number(6) PRIMARY KEY,
Ename varchar2(25),
job varchar2(50),
mgr Number(4),
hiredate date,
dept_id int,
foreign key (dept_id) references Department(dept_id)
);

insert into Employee values(1001,'Girjesh'	,	'Associate Engineer'   	,	1005,'06-NOV-2016',10);
insert into Employee values(1002,'Abhishek'	,	'Software Engineer'		,	1004,'06-APR-2014',20);
insert into Employee values(1003,'Rishabh'	,	'Database Engineer' 	,	1002,'16-MAY-2016',30);
insert into Employee values(1004,'Shashank'	,	'Financial Engineer'	,	1003,'06-AUG-2010',40);
insert into Employee values(1005,'Amit'		,	'EnterPrises Engineer'	,	1001,'26-SEP-2016',50);

drop table Asset cascade constraints;
CREATE TABLE Asset(
AssetId Number PRIMARY KEY,
AssetName varchar2(25),
AssetDes varchar2(25),
Quantity number,
Status varchar2(15)
);

drop table asset_Allocation cascade constraints;
CREATE TABLE Asset_Allocation(
AllocationId number PRIMARY KEY,
AssetId number,
Empno number,
Allocation_date date,
Release_date date,
foreign key (AssetId) references Asset(AssetId),
foreign key (Empno) references Employee(Empno)
);

select ename from employee where empno in(select mgr from employee where empno=1003);

commit;