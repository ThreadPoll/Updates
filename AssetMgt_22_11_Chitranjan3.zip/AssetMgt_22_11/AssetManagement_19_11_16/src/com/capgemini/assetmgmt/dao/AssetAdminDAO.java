package com.capgemini.assetmgmt.dao;

import java.util.List;

import com.capgemini.assetmgmt.dto.Asset;
import com.capgemini.assetmgmt.dto.AssetAllocation;
import com.capgemini.assetmgmt.exception.AssetAdminException;

public interface AssetAdminDAO {
	public void addAsset(Asset asset) throws AssetAdminException;
	public void updateAsset(Asset asset) throws AssetAdminException;
	public Asset searchAsset(String assetId) throws AssetAdminException;
	public List<AssetAllocation> displayRequest() throws AssetAdminException;
	public void actRequestAdmin(Asset asset) throws AssetAdminException;
}
