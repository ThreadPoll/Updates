package com.capgemini.assetmgmt.dao;

import com.capgemini.assetmgmt.dto.User;
import com.capgemini.assetmgmt.exception.AssetAuthenticationException;

public interface AssetAuthenticationDAO {

	public boolean isValidUser(User user) throws AssetAuthenticationException;
}
