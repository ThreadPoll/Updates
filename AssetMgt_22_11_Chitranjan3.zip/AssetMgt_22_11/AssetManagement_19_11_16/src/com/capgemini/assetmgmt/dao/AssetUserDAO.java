package com.capgemini.assetmgmt.dao;

import java.util.List;

import com.capgemini.assetmgmt.dto.Asset;
import com.capgemini.assetmgmt.dto.AssetAllocation;
import com.capgemini.assetmgmt.exception.AssetUserException;

public interface AssetUserDAO {


	public List<Asset> displayAsset() throws AssetUserException;
	public void raiseRequest(AssetAllocation assetAllocation) throws AssetUserException;
}
