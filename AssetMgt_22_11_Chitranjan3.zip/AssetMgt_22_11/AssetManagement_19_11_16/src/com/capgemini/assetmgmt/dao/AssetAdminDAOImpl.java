package com.capgemini.assetmgmt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.assetmgmt.dto.Asset;
import com.capgemini.assetmgmt.dto.AssetAllocation;
import com.capgemini.assetmgmt.exception.AssetAdminException;
import com.capgemini.assetmgmt.factory.DbUtil;

public class AssetAdminDAOImpl implements AssetAdminDAO{

	@Override
	public void addAsset(Asset asset) throws AssetAdminException {
		
		String queryOne = "INSERT INTO asset VALUES(?,?,?,?,?)";
		try(Connection con = DbUtil.getConnection()) {
			
			PreparedStatement pstm = con.prepareStatement(queryOne);
			pstm.setInt(1, asset.getAssetId());
			pstm.setString(2, asset.getAssetName());
			pstm.setString(3, asset.getAssetDes());
			pstm.setInt(4, asset.getQuantity());
			pstm.setString(5, asset.getStatus());
			
			pstm.executeUpdate();
		} catch (Exception e) {
			throw new AssetAdminException("Can Not insert the asset");
		}
				
	}

	@Override
	public void updateAsset(Asset asset) throws AssetAdminException {
		
		String queryTwo = "UPDATE asset SET assetName=? , assetDes=? , quantity=? , status =? WHERE assetId =?";
		try(Connection con = DbUtil.getConnection()){
			
			PreparedStatement pstm = con.prepareStatement(queryTwo);
			pstm.setString(1, asset.getAssetName());
			pstm.setString(2, asset.getAssetDes());
			pstm.setInt(3, asset.getQuantity());
			pstm.setString(4, asset.getStatus());
			pstm.setInt(5, asset.getAssetId());
			
			pstm.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw new AssetAdminException("CanNot update the asset");
		}
	}

	@Override
	public Asset searchAsset(String assetId) throws AssetAdminException {
		Asset asset = new Asset();
		String queryThree="select * from asset where assetId=?";
		try(Connection con = DbUtil.getConnection()) {
		
			if(isValidId(assetId)){
			PreparedStatement pstm = con.prepareStatement(queryThree);
			pstm.setString(1, assetId);
			
			ResultSet res = pstm.executeQuery();
			
			while(res.next()){
				asset.setAssetId(res.getInt(1));
				asset.setAssetName(res.getString(2));
				asset.setAssetDes(res.getString(3));
				asset.setQuantity(res.getInt(4));
				asset.setStatus(res.getString(5));
				
				}
			}
		} catch (Exception e) {
			throw new AssetAdminException("Unable lto fetch the given information");
		}
		return asset;
	}
	
	public boolean isValidId(String id) throws AssetAdminException{
		
		String queryFour = "select assetid from asset where assetid=?";
		int flag = 0;
		
		try(Connection con = DbUtil.getConnection()) {
			PreparedStatement pstm = con.prepareStatement(queryFour);
			pstm.setString(1, id);
			ResultSet res = pstm.executeQuery();
			if(res.next()){
				flag = 1;
			}
		} catch (Exception e) {
			throw new AssetAdminException("Id Does Not Exist");
		}
		
		if(flag==0){
			return false;
		}
		else{
			return true;
		}
		
	}

	@Override
	public List<AssetAllocation> displayRequest() throws AssetAdminException {
		List<AssetAllocation> requestList = new ArrayList<AssetAllocation>();
		
		String queryOne = "SELECT * FROM Asset_Allocation";
		
		try(Connection con = DbUtil.getConnection()) {
			
			PreparedStatement pstm = con.prepareStatement(queryOne);
			
			ResultSet res = pstm.executeQuery();
			
			while(res.next()){
				AssetAllocation assetAllocation = new AssetAllocation();
				assetAllocation.setAllocationId(res.getInt(1));
				assetAllocation.setAssetId(res.getInt(2));
				assetAllocation.setEmpNo(res.getInt(3));
				assetAllocation.setAllocationDate(res.getDate(4));
				assetAllocation.setReleaseDate(res.getDate(5));
				
				requestList.add(assetAllocation);				
			}
			
		} catch (Exception e) {
			throw new AssetAdminException("Unable to fetch the given information");
		}		
		return requestList;
	}

	@Override
	public void actRequestAdmin(Asset asset) throws AssetAdminException {
		String query = "Update asset set status='Allocated' where assetid=?";
		try (Connection con = DbUtil.getConnection()){
			PreparedStatement pstm = con.prepareStatement(query);
			pstm.setInt(1, asset.getAssetId());
			pstm.execute();
		} catch (Exception e) {
			throw new AssetAdminException("Cannot set the value allocated");
		}
	}

}
