package com.capgemini.assetmgmt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.capgemini.assetmgmt.dto.User;
import com.capgemini.assetmgmt.exception.AssetAuthenticationException;
import com.capgemini.assetmgmt.factory.DbUtil;

public class AssetAuthenticationDAOImpl implements AssetAuthenticationDAO{

	@Override
	public boolean isValidUser(User user) throws AssetAuthenticationException {
		String query = "select * from user_master where userid=? and username=? and userpassword=? and usertype=?";
		int flag=0;
		
		try(Connection con = DbUtil.getConnection()){
			PreparedStatement pstm = con.prepareStatement(query);
			pstm.setString(1, user.getUserId());
			pstm.setString(2, user.getUserName());
			pstm.setString(3, user.getUserPassword());
			pstm.setString(4, user.getUserType().toString());			
			ResultSet res = pstm.executeQuery();
			while(res.next()){
				flag=1;
			}
		}catch (Exception e) {
			throw new AssetAuthenticationException("Problem in Validating");
		}
		if(flag==0){
			throw new AssetAuthenticationException("InValid Credential");
		}else {
			return true;
		}
		
	}
}
