package com.capgemini.assetmgmt.service;

import java.util.HashMap;

import com.capgemini.assetmgmt.exception.AssetAuthenticationException;

public interface AssetAuthenticationService {

	public boolean isValidUser(HashMap<String , String> userDetails) throws AssetAuthenticationException;
}
