package com.capgemini.assetmgmt.exception;

public class AssetException extends Exception {

	private static final long serialVersionUID = 1491408500799257309L;

	public AssetException() {
		super();
	}

	public AssetException(String message) {
		super(message);
	}

	public AssetException(Throwable cause) {
		super(cause);
	}

	
}
