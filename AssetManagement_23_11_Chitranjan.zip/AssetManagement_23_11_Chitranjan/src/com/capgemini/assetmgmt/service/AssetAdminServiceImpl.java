package com.capgemini.assetmgmt.service;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.capgemini.assetmgmt.dao.AssetAdminDAO;
import com.capgemini.assetmgmt.dao.AssetAdminDAOImpl;
import com.capgemini.assetmgmt.dto.Asset;
import com.capgemini.assetmgmt.dto.AssetAllocation;
import com.capgemini.assetmgmt.exception.AssetAdminException;
import com.capgemini.assetmgmt.factory.DbUtil;

public class AssetAdminServiceImpl implements AssetAdminService{

	private AssetAdminDAO adminDao;
	public AssetAdminServiceImpl() {
		adminDao = new AssetAdminDAOImpl();
	}
	
	@Override
	public void addAsset(HashMap<String, String> assetDetails)
			throws AssetAdminException {
		Asset asset = new Asset();
		asset.setAssetId(Integer.parseInt(assetDetails.get("assetId")));
		asset.setAssetName(assetDetails.get("assetName"));
		asset.setAssetDes(assetDetails.get("assetDes"));
		asset.setQuantity(Integer.parseInt(assetDetails.get("quantity")));
		asset.setStatus(assetDetails.get("status"));
		
		adminDao.addAsset(asset);
	}
	@Override
	public void updateAsset(HashMap<String, String> assetDetails)
			throws AssetAdminException {
		Asset asset = new Asset();

		asset.setAssetId(Integer.parseInt(assetDetails.get("assetId")));
		asset.setAssetName(assetDetails.get("assetName"));
		asset.setAssetDes(assetDetails.get("assetDes"));
		asset.setQuantity(Integer.parseInt(assetDetails.get("quantity")));
		asset.setStatus(assetDetails.get("status"));
		
		adminDao.updateAsset(asset);
		
	}

	@Override
	public HashMap<String, String> searchAsset(String assetId)
			throws AssetAdminException {
		Asset asset = adminDao.searchAsset(assetId);
		HashMap<String, String> assetDetails = new HashMap<String, String>();
		assetDetails.put("assetId", asset.getAssetId()+"");
		assetDetails.put("assetName", asset.getAssetName());
		assetDetails.put("assetDes", asset.getAssetDes());
		assetDetails.put("quantity", asset.getQuantity()+"");
		assetDetails.put("status", asset.getStatus());
		
		return assetDetails;
	}

	@Override
	public List<HashMap<String, String>> displayRequest()
			throws AssetAdminException {
		List<HashMap<String, String>> requestList = new ArrayList<HashMap<String,String>>();
		List<AssetAllocation> myAssetList = adminDao.displayRequest();
		for (int index = 0; index < myAssetList.size(); index++) {
			DateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
			AssetAllocation assetAllocation = myAssetList.get(index);
			
			HashMap<String, String> requestDetails = new HashMap<String, String>();
			requestDetails.put("allocationId", assetAllocation.getAllocationId()+"");
			requestDetails.put("assetId", assetAllocation.getAssetId()+"");
			requestDetails.put("empNo", assetAllocation.getEmpNo()+"");
			requestDetails.put("allocationDate", formatter.format(assetAllocation.getAllocationDate())+"");
			requestDetails.put("releaseDate", formatter.format(assetAllocation.getReleaseDate())+"");
			requestList.add(requestDetails);
		}
		return requestList;
	}

	@Override
	public void actrequestAdmin(HashMap<String, String> actRequest)
			throws AssetAdminException {
		Asset asset = new Asset();
		asset.setAssetId(Integer.parseInt(actRequest.get("assetId")));
		adminDao.actRequestAdmin(asset);
	}
	
}
