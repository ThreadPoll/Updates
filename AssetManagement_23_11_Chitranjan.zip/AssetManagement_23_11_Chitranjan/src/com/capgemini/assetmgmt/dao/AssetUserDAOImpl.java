package com.capgemini.assetmgmt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.assetmgmt.dto.Asset;
import com.capgemini.assetmgmt.dto.AssetAllocation;
import com.capgemini.assetmgmt.exception.AssetUserException;
import com.capgemini.assetmgmt.factory.DbUtil;

public class AssetUserDAOImpl implements AssetUserDAO{

	@Override
	public List<Asset> displayAsset() throws AssetUserException {
		List<Asset> assetList = new ArrayList<Asset>();
		String queryOne = "SELECT * FROM asset";
		
		try(Connection con = DbUtil.getConnection()) {
			
			PreparedStatement pstm = con.prepareStatement(queryOne);
			
			ResultSet res = pstm.executeQuery();
			
			while(res.next()){
				Asset asset = new Asset();
				asset.setAssetId(res.getInt(1));
				asset.setAssetName(res.getString(2));
				asset.setAssetDes(res.getString(3));
				asset.setQuantity(res.getInt(4));
				asset.setStatus(res.getString(5));
				
				assetList.add(asset);				
			}
			
		} catch (Exception e) {
			throw new AssetUserException("Unable to fetch the given information");
		}		
		return assetList;

	}

	@Override
	public void raiseRequest(AssetAllocation assetAllocation)
			throws AssetUserException {
		String queryTwo = "INSERT INTO Asset_allocation VALUES(?,?,?,?,?)";
		try(Connection con = DbUtil.getConnection()) {
			PreparedStatement pstm = con.prepareStatement(queryTwo);
			pstm.setInt(1, assetAllocation.getAllocationId());
			pstm.setInt(2, assetAllocation.getAssetId());
			pstm.setInt(3, assetAllocation.getEmpNo());
			java.sql.Date allocationDate = new java.sql.Date(assetAllocation.getAllocationDate().getTime());
			java.sql.Date releaseDate = new java.sql.Date(assetAllocation.getReleaseDate().getTime());
			pstm.setDate(4, allocationDate);
			pstm.setDate(5, releaseDate);
			
			pstm.executeQuery();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			throw new AssetUserException("Problem in firing the resquest for asset.");
		}
		
	}

}
