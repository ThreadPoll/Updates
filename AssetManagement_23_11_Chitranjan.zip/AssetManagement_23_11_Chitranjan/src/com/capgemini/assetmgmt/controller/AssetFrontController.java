package com.capgemini.assetmgmt.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.assetmgmt.dto.UserType;
import com.capgemini.assetmgmt.exception.AssetAdminException;
import com.capgemini.assetmgmt.exception.AssetAuthenticationException;
import com.capgemini.assetmgmt.exception.AssetUserException;
import com.capgemini.assetmgmt.service.AssetAdminService;
import com.capgemini.assetmgmt.service.AssetAdminServiceImpl;
import com.capgemini.assetmgmt.service.AssetAuthenticationService;
import com.capgemini.assetmgmt.service.AssetAuthenticationServiceImpl;
import com.capgemini.assetmgmt.service.AssetUserService;
import com.capgemini.assetmgmt.service.AssetUserServiceImpl;

@WebServlet("/AssetFrontController")
public class AssetFrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private AssetAuthenticationService authenticationService;
	private AssetAdminService adminService;
	private AssetUserService userService;
	
    public AssetFrontController() {
    	authenticationService = new AssetAuthenticationServiceImpl();
    	adminService = new AssetAdminServiceImpl();
    	userService = new AssetUserServiceImpl();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	@SuppressWarnings("unchecked")
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String action = request.getParameter("action");
		switch (action) {
		case "login":
		{
			
			String userId = request.getParameter("userId");
			String userName = request.getParameter("userName");
			String userPassword = request.getParameter("userPassword");
			String userType = request.getParameter("userType");
			
			HashMap<String , String> userDetails = new HashMap<>();
			
			userDetails.put("userId", userId);
			userDetails.put("userName", userName);
			userDetails.put("userPassword", userPassword);
			userDetails.put("userType", userType);
			
			try {
				boolean check = authenticationService.isValidUser(userDetails);
				if(check){
					HttpSession session = request.getSession(true);
					session.setAttribute("userDetails", userDetails);
					
					HashMap<String , String> userDetails1 = (HashMap<String, String>) session.getAttribute("userDetails");
					UserType userType1 = UserType.valueOf(userDetails1.get("userType"));
					if((userType1.toString()).equals("admin")){
						RequestDispatcher rd = request.getRequestDispatcher("adminMenu.jsp");
						rd.forward(request, response);
					}else if((userType1.toString()).equals("manager")){
						RequestDispatcher rd = request.getRequestDispatcher("managerMenu.jsp");
						rd.forward(request, response);
					}
				}
			} catch (AssetAuthenticationException e) {
				RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
				request.setAttribute("errorMessage", e.getMessage());
				rd.forward(request, response);
			}
			
		}
			break;

		case "addAssetAdmin":{
			String assetId = request.getParameter("assetId");
			String assetName = request.getParameter("assetName");
			String assetDes = request.getParameter("assetDes");
			String quantity = request.getParameter("quantity");
			String status = request.getParameter("status");
			
			HashMap<String , String> assetDetails = new HashMap<>();
			
			assetDetails.put("assetId", assetId);
			assetDetails.put("assetName", assetName);
			assetDetails.put("assetDes", assetDes);
			assetDetails.put("quantity", quantity);
			assetDetails.put("status", status);
			
			try {
				adminService.addAsset(assetDetails);
				RequestDispatcher rd = request.getRequestDispatcher("adminMenu.jsp");
				rd.forward(request, response);
			
			} catch (AssetAdminException e) {
				RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
				request.setAttribute("errorMessage", e.getMessage());
				rd.forward(request, response);
			}
		}
			break;
			
		case "fetch":{
			String assetId = request.getParameter("assetId");
			try {
				HashMap<String , String> assetDetails = adminService.searchAsset(assetId);
				RequestDispatcher rd = request.getRequestDispatcher("updateAsset.jsp");
				request.setAttribute("assetDetails", assetDetails);
				rd.forward(request, response);
					
			} catch (AssetAdminException e) {
				RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
				request.setAttribute("errorMessage", e.getMessage());
				rd.forward(request, response);}
		}
		break;
		
		case "updateAssetAdmin":{
			String assetId = request.getParameter("assetId");
			String assetName = request.getParameter("assetName");
			String assetDes = request.getParameter("assetDes");
			String quantity = request.getParameter("quantity");
			String status = request.getParameter("status");
			
			HashMap<String , String> assetDetails = new HashMap<>();
			
			assetDetails.put("assetId", assetId);
			assetDetails.put("assetName", assetName);
			assetDetails.put("assetDes", assetDes);
			assetDetails.put("quantity", quantity);
			assetDetails.put("status", status);
			
			try {
				adminService.updateAsset(assetDetails);
				RequestDispatcher rd = request.getRequestDispatcher("adminMenu.jsp");
				rd.forward(request, response);				
			} catch (AssetAdminException e) {
				RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
				request.setAttribute("errorMessage", e.getMessage());
				rd.forward(request, response);
			}
		}
		break;
		
		case "displayRequestAdmin":{
			String id=null;
			try {
				List<HashMap<String, String>> requestList = adminService.displayRequest();
				RequestDispatcher rd = request.getRequestDispatcher("table.jsp");
				request.setAttribute("requestList", requestList);
				request.setAttribute("id", id);
				rd.forward(request, response);
			} catch (AssetAdminException e) {
				RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
				request.setAttribute("errorMessage", e.getMessage());
				rd.forward(request, response);
			}		
		}
		break;
		
		case "actRequest":{
			String allocationId = null;
			String assetId = null;
			String empNo = null;
			String allocationDate = null;
			String releaseDate = null;
			
			if(request.getParameter("approve") != null && (request.getParameter("approve")).equals("approve")){
				allocationId = request.getParameter("allocationId");
				assetId = request.getParameter("assetId");
				empNo = request.getParameter("empNo");
				allocationDate = request.getParameter("allocationDate");
				releaseDate = request.getParameter("releaseDate");
				
				HashMap<String, String> actRequest = new HashMap<>();
				actRequest.put("allocationId", allocationId);
				actRequest.put("assetId", assetId);
				actRequest.put("empNo", empNo);
				actRequest.put("allocationDate", allocationDate);
				actRequest.put("releaseDate", releaseDate);
				
				String va = request.getParameter("value");
				System.out.println(va);
				System.out.println(actRequest);
				
				try {
					adminService.actrequestAdmin(actRequest);
				} catch (AssetAdminException e) {
					RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
					request.setAttribute("errorMessage", e.getMessage());
					rd.forward(request, response);
				}
			}else if(request.getParameter("reject") != null && (request.getParameter("reject")).equals("reject")){
				allocationId = request.getParameter("allocationId");
				assetId = request.getParameter("assetId");
				empNo = request.getParameter("empNo");
				allocationDate = request.getParameter("allocationDate");
				releaseDate = request.getParameter("releaseDate");
				
				HashMap<String, String> actRequest = new HashMap<>();
				actRequest.put("allocationId", allocationId);
				actRequest.put("assetId", assetId);
				actRequest.put("empNo", empNo);
				actRequest.put("allocationDate", allocationDate);
				actRequest.put("releaseDate", releaseDate);
				
				try {
					adminService.actrequestAdmin(actRequest);
				} catch (AssetAdminException e) {
					RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
					request.setAttribute("errorMessage", e.getMessage());
					rd.forward(request, response);
				}
			}
			
		}
		break;
		
		case "displayAssetManager":{
			try {
				List<HashMap<String, String>> assetList = userService.displayAsset();
				
				RequestDispatcher rd = request.getRequestDispatcher("displayAssetManager.jsp");
				request.setAttribute("assetList", assetList);
				rd.forward(request, response);
			} catch (AssetUserException e) {
				RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
				request.setAttribute("errorMessage", e.getMessage());
				rd.forward(request, response);
			}
		}
		break;
		
		case "raiseRequestManager":{
			String allocationId = request.getParameter("allocationId");
			String assetId = request.getParameter("assetId");
			String empNo = request.getParameter("empNo");
			String allocationDate = request.getParameter("allocationDate");
			String releaseDate = request.getParameter("releaseDate");
			
			HashMap<String, String> allocationDetails = new HashMap<String, String>();
			allocationDetails.put("allocationId", allocationId);
			allocationDetails.put("assetId", assetId);
			allocationDetails.put("empNo", empNo);
			allocationDetails.put("allocationDate", allocationDate);
			allocationDetails.put("releaseDate", releaseDate);
			
			try {
				userService.raiseRequest(allocationDetails);
				RequestDispatcher rd = request.getRequestDispatcher("requestRaised.jsp");
				request.setAttribute("allocationDetails", allocationDetails);
				rd.forward(request, response);
				
			} catch (AssetUserException e) {
				RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
				request.setAttribute("errorMessage", e.getMessage());
				rd.forward(request, response);
			}
		}
		break;
	}

	}
}
