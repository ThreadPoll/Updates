package com.capgemini.assetmgmt.factory;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.capgemini.assetmgmt.exception.AssetException;

public class DbUtil {

static Connection con = null;
	
	public static Connection getConnection() throws AssetException{
			
		Connection connection = null;
		
		try {
			InitialContext context = new InitialContext();
			
			DataSource source = (DataSource) context.lookup("java:/OracleDS/MyDS");
			
			connection = source.getConnection();
			} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
		
	}

}
