package com.capgemini.assetmgmt.service;

import java.util.HashMap;
import java.util.List;

import com.capgemini.assetmgmt.exception.AssetUserException;

public interface AssetUserService {

	public List<HashMap<String , String>> displayAsset() throws AssetUserException;
	public void raiseRequest(HashMap<String, String> allocationDetails) throws AssetUserException;
}
